<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
| -------------------------------------------------------------------
| DATABASE CONNECTIVITY SETTINGS
| -------------------------------------------------------------------
| This file will contain the settings needed to access your database.
|
| For complete instructions please consult the "Database Connection"
| page of the User Guide.
|
| -------------------------------------------------------------------
| EXPLANATION OF VARIABLES
| -------------------------------------------------------------------
|
|	['hostname'] The hostname of your database server.
|	['username'] The username used to connect to the database
|	['password'] The password used to connect to the database
|	['database'] The name of the database you want to connect to
|	['dbdriver'] The database type. ie: mysql.  Currently supported:
				 mysql, mysqli, postgre, odbc, mssql, sqlite, oci8
|	['dbprefix'] You can add an optional prefix, which will be added
|				 to the table name when using the  Active Record class
|	['pconnect'] TRUE/FALSE - Whether to use a persistent connection
|	['db_debug'] TRUE/FALSE - Whether database errors should be displayed.
|	['cache_on'] TRUE/FALSE - Enables/disables query caching
|	['cachedir'] The path to the folder where cache files should be stored
|	['char_set'] The character set used in communicating with the database
|	['dbcollat'] The character collation used in communicating with the database
|
| The $active_group variable lets you choose which connection group to
| make active.  By default there is only one group (the "default" group).
|
| The $active_record variables lets you determine whether or not to load
| the active record class
*/

$active_group = "ecs";
$active_record = TRUE;

$db['system']['hostname'] = "localhost";
$db['system']['username'] = "root";
$db['system']['password'] = "";
$db['system']['database'] = "myaccount";
$db['system']['dbdriver'] = "mysql";
$db['system']['dbprefix'] = "";
$db['system']['pconnect'] = TRUE;
$db['system']['db_debug'] = FALSE;
$db['system']['cache_on'] = FALSE;
$db['system']['cachedir'] = "";
$db['system']['char_set'] = "utf8";
$db['system']['dbcollat'] = "utf8_general_ci";

$db['server']['hostname'] = "ecspro2";
$db['server']['username'] = "jhill";
$db['server']['password'] = "jonhil";
$db['server']['database'] = "";
$db['server']['dbdriver'] = "odbc";
$db['server']['dbprefix'] = "";
$db['server']['pconnect'] = FALSE;		// unixODBC can't handle persistent connections well
$db['server']['db_debug'] = FALSE;
$db['server']['cache_on'] = FALSE;
$db['server']['cachedir'] = "";
$db['server']['char_set'] = "";
$db['server']['dbcollat'] = "";

/* End of file database.php */
/* Location: ./system/application/config/database.php */