<html>
<head>
<title>Quick 'n Easy CodeIgniter Query Browser</title>

<style type="text/css">

body {
 background-color: #fff;
 margin: 40px;
 font-family: Lucida Grande, Verdana, Sans-serif;
 font-size: 14px;
 color: #4F5155;
}

a {
 color: #003399;
 background-color: transparent;
 font-weight: normal;
}

h1 {
 color: #444;
 background-color: transparent;
 border-bottom: 1px solid #D0D0D0;
 font-size: 16px;
 font-weight: bold;
 margin: 24px 0 2px 0;
 padding: 5px 0 6px 0;
}

code {
 font-family: Monaco, Verdana, Sans-serif;
 font-size: 12px;
 background-color: #f9f9f9;
 border: 1px solid #D0D0D0;
 color: #002166;
 display: block;
 margin: 14px 0 14px 0;
 padding: 12px 10px 12px 10px;
}

table {
 width:100%;
 font-family: Monaco, Verdana, Sans-serif;
 font-size: 12px;
 background-color: #f9f9f9;
 border: 1px solid #D0D0D0;
 color: #002166;
 margin: 14px 0 14px 0;
 padding: 12px 2%;
}
td, th {
 padding:4px;
}
th {
 border-bottom:3px solid #D0D0D0;
}

dd code { cursor:pointer; }

.error {
 background:pink;
 padding:1px 12px;
 font-weight:bold;
 margin:12px 0;
 color:black;
 border:1px solid red;
}

</style>
<script src="/assets/js/jquery-1.2.6.pack.js" type="text/javascript"></script>
<script type="text/javascript">
//<![CDATA[
	$(document).ready(function(){
		$('dd code').each(function() {
			$(this).bind('click', function() {
				document.queryform.query.value = $(this).html();
				document.queryform.name.value  = $(this).parent().prev().children('label').children('span').html();
				document.queryform.submit();
			});
		});
	});
//]]>
</script>
</head>
<body>

	<h1>Quick 'n Easy CodeIgniter Query Browser</h1>
	
	
	<? if($this->validation->error_string): ?>
	<div class="error"><?=$this->validation->error_string; ?></div>
	<? endif; ?>
	
	
	<form action="<?=site_url('qb'); ?>" method="post" name="queryform">
	
		<h2>SQL Query</h2>
		<p><label><?=form_textarea('query', $this->validation->query); ?></label></p>
		<p><label><?=form_checkbox('save', '1'); ?> Save this query as </label>
		<?=form_input('name', $this->validation->name); ?></p>
		<p><?=form_submit('submit', 'Submit'); ?>

		
		<? if(strlen($resulttab)): ?>
			<hr />
		
			<h2><?=$results; ?> Results.</h2>
			<?=$resulttab; ?>
		<? endif; ?>
		
		
		<? if(count($saved_queries)): ?>
			<hr />
		
			<h2>Saved Queries</h2>
			<dl>
			<? foreach($saved_queries as $i => $query): ?>
				<dt><label><?=form_checkbox("delete[]", $query->id); ?>  <span><?=$query->name; ?></span></label></dt>
				<dd><code><?=$query->query; ?></code></dd>
			<? endforeach; ?>
			</dl>
			<p><?=form_submit('submit', 'Delete'); ?>
		<? endif; ?>
	
	
	</form>	
	
	<hr />
	
	<p><br />Page rendered in {elapsed_time} seconds</p>

</body>
</html>