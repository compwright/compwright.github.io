<?php

class Qb extends Controller {

	function Qb()
	{
		parent::Controller();
		$this->sysdb = $this->load->database('system', TRUE);
		$this->srvdb = $this->load->database('server', TRUE);

		$this->sysdb->query(
"CREATE TABLE IF NOT EXISTS `querybrowser` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(50) default NULL,
  `query` text NOT NULL,
  PRIMARY KEY  (`id`)
);");
		
		$this->load->library('validation');
		$this->load->library('table');
		$this->load->helper('form');
		$this->load->helper('url');
	}
	
	function index()
	{
		$this->validation->set_fields(array(
			'name' 		=> 'Query name',
			'query'		=> 'SQL Query'
		));
		$this->validation->set_rules(array(
			'name' 		=> 'maxlength[50]|trim|ucwords',
			'query'		=> '',
			'submit'	=> 'required'
		));
		
		if($this->validation->run())
		{
			switch($this->input->post('submit'))
			{
				case 'Submit':
					
					if(!strlen($this->input->post('query'))) {
						$this->validation->error_string .= '<p>No query specified!</p>';
						break;
					}
					
					if($this->input->post('save')) {
						$this->sysdb->insert('querybrowser', array(
							'name'	=> $this->input->post('name'),
							'query'	=> $this->input->post('query')
						));
					}
					
					$result = $this->srvdb->query($this->input->post('query'));
					if(!$result) {
						$this->validation->error_string .=
						"<p>Query Error {$this->srvdb->_error_number()}: {$this->srvdb->_error_message()}</p>";
					} else {
						$ra = $result->result_array();
						$this->table->set_heading(array_keys($ra[0]));
						$data['resulttab'] = $this->table->generate($ra);
						$data['results']= count($ra);
					}
					
					break;
					
				case 'Delete':
					
					foreach((array) $_POST['delete'] as $key => $val) {
						$this->sysdb->delete('querybrowser', array('id' => (int) $val));
					}
					
					break;
			}
		}
		
		$data['saved_queries'] = $this->sysdb->get('querybrowser')->result();
		$this->load->view('qb', $data);
	}
}

/* End of file welcome.php */
/* Location: ./system/application/controllers/welcome.php */