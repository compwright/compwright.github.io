Quick 'n Simple Query Browser
=============================
Author: Jonathon Hill (jonathon@compwright.com)
Date: 9/11/2008
Version: 1.0

This is a very simple and lightweight SQL query browser built on CodeIgniter. It supports any database CodeIgniter supports (which includes MySQL, PgSQL, MSSQL, ODBC...).

I built it because I needed to experiment with some Informix queries, and Informix uses non-standard SQL syntax. This simple browser is fast, intuitive, and FREE.


--- Minimum System Requirements ---

* Apache 2
* MySQL 4
* PHP 5


--- Installation ---

1. Extract the zipfile into your desired web host directory.

2. Edit app/config/database.php and put in the information specific to the databases you will be using this with. The "system" database is a MySQL database used to store any queries you would like to save. This program will automatically create a table for this called "querybrowser" the first time it runs.

The "server" database is the database you want to query, and can be any type of database that CodeIgniter supports.

3. [optional] If you are installing this query browser to a subfolder instead of the document root, you will need to edit the "base_url" configuration variable in app/config/config.php. Note that this query browser expects the assets folder to be at the document root.